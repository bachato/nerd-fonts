
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 00e376df7089411e27947ef011449c5686b3c7d0
        Author: allcontributors[bot] <46447321+allcontributors[bot]@users.noreply.github.com>
        Date:   Tue Jan 7 13:51:04 2025 +0100
        
            docs: add realguse as a contributor for review (#1781)
            
            * docs: update CONTRIBUTORS.md
            
            * docs: update .all-contributorsrc
            
            ---------
            
            Co-authored-by: allcontributors[bot] <46447321+allcontributors[bot]@users.noreply.github.com>
